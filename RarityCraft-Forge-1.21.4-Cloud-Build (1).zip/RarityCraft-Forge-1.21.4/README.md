# RarityCraft — Forge 1.21.4

RarityCraft is a Forge mod prototype targeting Minecraft Java Edition 1.21.4 and Forge 54.1.22. This source project is designed to build on GitHub Actions so a Java 21 JDK does not need to be installed on your computer.

## Implemented in this source version

- Seven rarity tiers and the agreed weighted base chances: Common 45%, Uncommon 25%, Rare 15%, Epic 8%, Legendary 5%, Mythic 1.5%, Divine 0.5%.
- Crafted output stacks receive a rarity-coloured name prefix.
- Higher-rarity ingredients bias the next crafting roll toward higher tiers.
- Rarity weapons increase melee/ranged damage.
- Rarity tools increase mining speed.
- Rarity food grants tier-scaled temporary effects after eating.
- Armour bonuses: Night Vision, Water Breathing, Resistance, Speed, Jump Boost, and Slow Falling at higher tiers.
- Epic+ boots reduce fall damage; Mythic/Divine boots prevent it.
- Mythic chestplate Shadow Cloak prototype: crouching hides the player's full rendered model on the client.
- GitHub Actions workflow to build the JAR online with Java 21.

## Important limitations

This is a development prototype, **not a verified, feature-complete release**. It has not yet been compiled or tested in a running Minecraft client in this environment. Rarity is currently stored as a display-name prefix, not a dedicated item data component. The following requested systems are not yet implemented: rarity-preserving placed crafting tables, crafting-table rarity bonuses, furnace/blast-furnace/smoker speed and bonus-output upgrades, every category-specific ability, true invisibility of armour/held items for other clients, and a full multiplayer test pass. Do not treat this ZIP as a finished drop-in mod JAR.

## Build the JAR in GitHub Actions (no local Java installation)

1. On GitHub, create a **new empty repository** named `RarityCraft`.
2. Download and extract this ZIP.
3. Upload the *contents* of the `RarityCraft-Forge-1.21.4` folder to the repository root. Ensure `.github/workflows/build.yml` is included (GitHub may hide `.github` folders in some file pickers; use GitHub's web upload or the desktop app if needed).
4. Open the repository's **Actions** tab and enable Actions if asked.
5. Run **Build RarityCraft Forge**, or make a commit to the default branch to trigger it.
6. When the workflow succeeds, open that run and download the `raritycraft-1.21.4` artifact. It contains the compiled `.jar`.
7. Put the `.jar` into the `mods` folder for a Minecraft 1.21.4 **Forge** profile in CurseForge.

If the workflow fails, open the run, copy the first relevant error from the build log, and use it to debug the project before trying the JAR in game.
