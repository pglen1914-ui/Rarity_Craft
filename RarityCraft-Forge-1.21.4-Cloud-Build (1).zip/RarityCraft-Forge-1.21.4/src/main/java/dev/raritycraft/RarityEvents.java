package dev.raritycraft;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Core gameplay hooks for the RarityCraft prototype. */
@Mod.EventBusSubscriber(modid = RarityCraft.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class RarityEvents {
    private RarityEvents() {}

    @SubscribeEvent
    public static void onCrafted(PlayerEvent.ItemCraftedEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        ItemStack output = event.getCrafting();
        if (output.isEmpty() || Rarity.fromDisplayName(output.getHoverName().getString()) != null) return;

        int bonus = 0;
        for (int slot = 0; slot < event.getInventory().getContainerSize(); slot++) {
            ItemStack ingredient = event.getInventory().getItem(slot);
            Rarity ingredientRarity = rarityOf(ingredient);
            if (ingredientRarity != null) bonus = Math.max(bonus, ingredientRarity.ordinal());
        }

        Rarity rarity = Rarity.rollWithBonus(bonus);
        Component originalName = output.getHoverName();
        output.setHoverName(Component.literal("[" + rarity.label + "] ").withStyle(rarity.colour)
                .append(originalName.copy().withStyle(ChatFormatting.RESET)));
    }

    /** Rarity weapons increase damage; higher tiers scale more strongly. */
    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) return;
        ItemStack weapon = attacker.getMainHandItem();
        Rarity rarity = rarityOf(weapon);
        if (rarity == null || rarity == Rarity.COMMON) return;
        float multiplier = 1.0F + (0.12F * rarity.ordinal());
        if (weapon.is(net.minecraft.world.item.Items.BOW)
                || weapon.is(net.minecraft.world.item.Items.CROSSBOW)
                || weapon.is(net.minecraft.world.item.Items.TRIDENT)) {
            multiplier += 0.0F; // ranged attacks use the same tier scaling
        }
        event.setAmount(event.getAmount() * multiplier);
    }

    /** Rarity tools mine faster. This affects the held tool, regardless of its material. */
    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
        Rarity rarity = rarityOf(event.getEntity().getMainHandItem());
        if (rarity == null || rarity == Rarity.COMMON) return;
        event.setNewSpeed(event.getNewSpeed() * (1.0F + 0.18F * rarity.ordinal()));
    }

    /** Mythic/Divine boots prevent fall damage; Epic+ boots reduce it. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        LivingEntity entity = event.getEntity();
        Rarity boots = rarityOf(entity.getItemBySlot(EquipmentSlot.FEET));
        if (boots == null || boots.ordinal() < Rarity.EPIC.ordinal()) return;
        if (boots.ordinal() >= Rarity.MYTHIC.ordinal()) {
            event.setCanceled(true);
        } else {
            event.setDamageMultiplier(Math.max(0.25F, 1.0F - 0.15F * (boots.ordinal() - Rarity.EPIC.ordinal() + 1)));
        }
    }

    /** Rarity food grants a short tier-dependent bonus after it is consumed. */
    @SubscribeEvent
    public static void onFoodEaten(LivingEntityUseItemEvent.Finish event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide()) return;
        ItemStack food = event.getItem();
        if (food.getItem().getFoodProperties(food, player) == null) return;
        Rarity rarity = rarityOf(food);
        if (rarity == null || rarity == Rarity.COMMON) return;
        int seconds = 8 + rarity.ordinal() * 4;
        if (rarity.ordinal() >= Rarity.UNCOMMON.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, seconds * 20, rarity.ordinal() >= Rarity.LEGENDARY.ordinal() ? 1 : 0, true, true));
        }
        if (rarity.ordinal() >= Rarity.RARE.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, seconds * 20, rarity.ordinal() >= Rarity.MYTHIC.ordinal() ? 1 : 0, true, true));
        }
        if (rarity.ordinal() >= Rarity.EPIC.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, seconds * 20, rarity.ordinal() >= Rarity.DIVINE.ordinal() ? 3 : 1, true, true));
        }
    }

    /** Armour bonuses are refreshed every two seconds to avoid repeatedly resetting effects every tick. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || player.tickCount % 40 != 0) return;

        Rarity helmet = rarityOf(player.getItemBySlot(EquipmentSlot.HEAD));
        Rarity chest = rarityOf(player.getItemBySlot(EquipmentSlot.CHEST));
        Rarity legs = rarityOf(player.getItemBySlot(EquipmentSlot.LEGS));
        Rarity boots = rarityOf(player.getItemBySlot(EquipmentSlot.FEET));

        if (helmet != null && helmet.ordinal() >= Rarity.RARE.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100, 0, true, false));
        }
        if (helmet != null && helmet.ordinal() >= Rarity.LEGENDARY.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 100, 0, true, false));
        }
        if (chest != null && chest.ordinal() >= Rarity.EPIC.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 100, Math.min(1, chest.ordinal() - Rarity.EPIC.ordinal()), true, false));
        }
        if (legs != null && legs.ordinal() >= Rarity.RARE.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, Math.min(2, legs.ordinal() - Rarity.RARE.ordinal()), true, false));
        }
        if (boots != null && boots.ordinal() >= Rarity.EPIC.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.JUMP, 100, Math.min(2, boots.ordinal() - Rarity.EPIC.ordinal()), true, false));
        }
        if (boots != null && boots.ordinal() >= Rarity.LEGENDARY.ordinal()) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, true, false));
        }
    }

    private static Rarity rarityOf(ItemStack stack) {
        return stack == null || stack.isEmpty() ? null : Rarity.fromDisplayName(stack.getHoverName().getString());
    }
}
