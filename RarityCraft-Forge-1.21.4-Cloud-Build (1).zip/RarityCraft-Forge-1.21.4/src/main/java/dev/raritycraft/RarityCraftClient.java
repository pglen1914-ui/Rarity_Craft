package dev.raritycraft;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.world.entity.EquipmentSlot;

/** Mythic chestplate Shadow Cloak: while sneaking, omit the complete player model. */
@Mod.EventBusSubscriber(modid = RarityCraft.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class RarityCraftClient {
    private RarityCraftClient() {}

    @SubscribeEvent
    public static void hideSneakingMythicPlayer(RenderPlayerEvent.Pre event) {
        Player player = event.getEntity();
        if (!player.isCrouching()) return;
        ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
        if (!chest.isEmpty() && Rarity.fromDisplayName(chest.getHoverName().getString()) == Rarity.MYTHIC) {
            event.setCanceled(true);
        }
    }
}
