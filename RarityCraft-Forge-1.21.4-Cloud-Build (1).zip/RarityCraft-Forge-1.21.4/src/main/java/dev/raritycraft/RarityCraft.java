package dev.raritycraft;

import net.minecraftforge.fml.common.Mod;

@Mod(RarityCraft.MOD_ID)
public final class RarityCraft {
    public static final String MOD_ID = "raritycraft";

    public RarityCraft() {
        // Event subscribers are registered automatically by @Mod.EventBusSubscriber.
    }
}
