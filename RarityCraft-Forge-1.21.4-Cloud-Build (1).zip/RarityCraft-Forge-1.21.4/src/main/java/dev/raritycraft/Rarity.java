package dev.raritycraft;

import net.minecraft.ChatFormatting;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public enum Rarity {
    COMMON("Common", 4500, ChatFormatting.WHITE),
    UNCOMMON("Uncommon", 2500, ChatFormatting.GREEN),
    RARE("Rare", 1500, ChatFormatting.BLUE),
    EPIC("Epic", 800, ChatFormatting.LIGHT_PURPLE),
    LEGENDARY("Legendary", 500, ChatFormatting.GOLD),
    MYTHIC("Mythic", 150, ChatFormatting.DARK_PURPLE),
    DIVINE("Divine", 50, ChatFormatting.AQUA);

    public final String label;
    public final int weight;
    public final ChatFormatting colour;

    Rarity(String label, int weight, ChatFormatting colour) {
        this.label = label;
        this.weight = weight;
        this.colour = colour;
    }

    public static Rarity roll() {
        return rollWithBonus(0);
    }

    /** bonus shifts probability toward higher tiers, in 0..6 steps. */
    public static Rarity rollWithBonus(int bonus) {
        int total = Arrays.stream(values()).mapToInt(r -> r.weight).sum();
        int roll = ThreadLocalRandom.current().nextInt(total);
        int cumulative = 0;
        Rarity chosen = COMMON;
        for (Rarity rarity : values()) {
            cumulative += rarity.weight;
            if (roll < cumulative) { chosen = rarity; break; }
        }
        for (int i = 0; i < Math.min(6, Math.max(0, bonus)); i++) {
            if (chosen.ordinal() < DIVINE.ordinal() && ThreadLocalRandom.current().nextBoolean()) {
                chosen = values()[chosen.ordinal() + 1];
            }
        }
        return chosen;
    }

    public static Rarity fromDisplayName(String name) {
        if (name == null) return null;
        for (Rarity rarity : values()) {
            if (name.startsWith("[" + rarity.label + "] ")) return rarity;
        }
        return null;
    }
}
